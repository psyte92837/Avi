package com.example.aviawatch

import android.annotation.SuppressLint
import android.content.Context
import android.os.SystemClock
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import kotlin.coroutines.resume

data class ScrapeResult(
    val offers: List<Offer> = emptyList(),
    val captcha: Boolean = false,
    val error: String? = null
)

/**
 * Открывает страницу поиска в WebView (как обычный браузер), ждёт пока
 * сайт догрузит результаты, и вытаскивает карточки билетов из DOM.
 *
 * Селекторы не привязаны к CSS-классам сайтов (они меняются каждую неделю):
 * ищем элементы с ценой, поднимаемся до ближайшего блока, где есть
 * время вылета и прилёта — это и есть карточка билета.
 */
object Scraper {

    private val EXTRACT_JS = """
(function(){
  var txt=(document.body&&document.body.innerText)||'';
  var captcha=/captcha|are you a person|press (&|and) hold|подтвердите,? что вы|я не робот|access denied|verify you are human/i.test(txt) && txt.length<4000;
  var priceRe=/(\d{1,3}(?:[    ]\d{3})+|\d{3,7})[    ]?(₽|руб|сом|KGS|₸|€|US\$|\$)/;
  var timeRe=/\b([01]?\d|2[0-3]):[0-5]\d\b/g;
  var all=document.querySelectorAll('span,div,p,strong,b,button,a');
  var cards=[];
  for(var i=0;i<all.length;i++){
    var e=all[i], et=e.textContent||'';
    if(et.length>30||!priceRe.test(et)) continue;
    var c=e;
    for(var k=0;k<16&&c.parentElement;k++){
      c=c.parentElement;
      var tm=(c.innerText||'').match(timeRe);
      if(tm&&tm.length>=2){ if(cards.indexOf(c)<0) cards.push(c); break; }
    }
  }
  cards=cards.filter(function(c){return !cards.some(function(o){return o!==c&&c.contains(o);});});
  var offers=cards.slice(0,80).map(function(c){
    var t=(c.innerText||'').replace(/[   ]/g,' ');
    var pm=t.match(priceRe);
    var times=t.match(timeRe)||[];
    var alts=[].slice.call(c.querySelectorAll('img')).map(function(m){return (m.alt||m.title||'').trim();})
      .filter(function(a,ix,s){return a.length>1&&a.length<60&&s.indexOf(a)===ix;});
    var st=t.match(/без пересад\S*|прям\S+ рейс|\d+\s*пересад\S*|non-?stop|direct|\d+\s*stops?/i);
    var a=c.querySelector('a[href]');
    return {price:pm?pm[1].replace(/\s/g,''):'',cur:pm?pm[2]:'',airline:alts.join(', '),
            dep:times[0]||'',arr:times[1]||'',stops:st?st[0]:'',href:a?a.href:'',text:t.slice(0,400)};
  }).filter(function(o){return o.price;});
  return {captcha:captcha,offers:offers,len:txt.length};
})();
""".trimIndent()

    @SuppressLint("SetJavaScriptEnabled")
    fun setup(wv: WebView) {
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.loadsImagesAutomatically = true
        wv.webViewClient = WebViewClient()   // открывать ссылки внутри WebView
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
    }

    private fun headless(ctx: Context): WebView {
        val wv = WebView(ctx.applicationContext)
        setup(wv)
        // без размера многие сайты ничего не рисуют
        val w = 1080; val h = 2400
        wv.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(h, View.MeasureSpec.EXACTLY))
        wv.layout(0, 0, w, h)
        return wv
    }

    private suspend fun WebView.eval(js: String): String =
        suspendCancellableCoroutine { c -> evaluateJavascript(js) { c.resume(it ?: "null") } }

    /**
     * @param view видимый WebView из интерфейса (чтобы пользователь мог сам пройти
     *             проверку «я не робот»), или null — тогда невидимый.
     */
    suspend fun scrape(
        ctx: Context, site: String, date: String, url: String,
        view: WebView? = null, timeoutMs: Long = 80_000
    ): ScrapeResult = withContext(Dispatchers.Main) {
        val own = view == null
        val wv = view ?: headless(ctx)
        try {
            wv.loadUrl(url)
            val start = SystemClock.elapsedRealtime()
            var last: List<Offer> = emptyList()
            var stable = 0
            while (true) {
                delay(3000)
                val elapsed = SystemClock.elapsedRealtime() - start
                val raw = wv.eval(EXTRACT_JS)
                val res = parse(raw, site, date, url)
                if (res.captcha && elapsed > 6000) {
                    // даём время пройти проверку вручную, если браузер видимый
                    if (own || elapsed > timeoutMs) return@withContext res
                    continue
                }
                if (res.offers.isNotEmpty() && res.offers.size == last.size && elapsed > 15_000) stable++
                else stable = 0
                if (res.offers.isNotEmpty()) last = res.offers
                // результаты перестали меняться ~9 сек — поиск завершён
                if (stable >= 3) return@withContext ScrapeResult(last)
                if (elapsed > timeoutMs) return@withContext ScrapeResult(last,
                    error = if (last.isEmpty()) "нет результатов за ${timeoutMs / 1000} с" else null)
            }
            @Suppress("UNREACHABLE_CODE") ScrapeResult()
        } catch (e: Exception) {
            ScrapeResult(error = e.message)
        } finally {
            if (own) wv.destroy() else wv.stopLoading()
        }
    }

    private fun parse(raw: String, site: String, date: String, url: String): ScrapeResult {
        if (raw == "null" || raw.isBlank()) return ScrapeResult()
        val o = JSONObject(raw)
        val arr = o.optJSONArray("offers")
        val list = ArrayList<Offer>()
        if (arr != null) for (i in 0 until arr.length()) {
            val x = arr.getJSONObject(i)
            val price = x.optString("price").toIntOrNull() ?: continue
            if (price < 500 && x.optString("cur") == "₽") continue   // мусор вроде «скидка 300 ₽»
            val airline = x.optString("airline").ifEmpty { guessAirline(x.optString("text")) }
            list += Offer(
                site = site, date = date, price = price, currency = x.optString("cur"),
                airline = airline, dep = x.optString("dep"), arr = x.optString("arr"),
                stops = x.optString("stops"),
                url = x.optString("href").takeIf { it.startsWith("http") } ?: url
            )
        }
        return ScrapeResult(list.sortedBy { it.price }, captcha = o.optBoolean("captcha"))
    }

    /** Если логотип без подписи — берём первую текстовую строку карточки без цифр. */
    private fun guessAirline(text: String): String {
        val skip = Regex("(?i)пересад|прям|багаж|выбрать|купить|дешев|быстр|лучш|в пути|select|best|cheap|fast")
        return text.lines().map { it.trim() }.firstOrNull {
            it.length in 2..40 && it.none(Char::isDigit) && !skip.containsMatchIn(it)
        } ?: ""
    }
}
