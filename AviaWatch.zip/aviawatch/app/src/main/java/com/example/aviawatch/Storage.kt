package com.example.aviawatch

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Когда присылать уведомление. */
object NotifyMode {
    const val DROP = 0     // только если цена стала ниже прежней
    const val LIMIT = 1    // каждый раз, когда цена ниже порога
    const val ALWAYS = 2   // после каждой проверки
}

/** Отслеживаемое направление со всеми опциями. */
data class Watch(
    val id: Long,
    val originName: String,
    val origin: String,          // IATA для Aviasales, напр. FRU
    val destName: String,
    val dest: String,
    val skyFrom: String,         // код для Skyscanner, напр. fru
    val skyTo: String,           // напр. mosc
    val dateFrom: String,        // yyyy-MM-dd
    val dateTo: String,
    val useAvia: Boolean,
    val useSky: Boolean,
    val notifyMode: Int,
    val maxPrice: Int,           // 0 = без порога
    val minDrop: Int,            // на сколько минимум должна упасть цена
    val directOnly: Boolean,
    val depFrom: Int,            // окно вылета, часы 0..24
    val depTo: Int,
    val airlines: String,        // только эти (через запятую), пусто = любые
    val excludeAirlines: String, // исключить
    val maxDates: Int,           // сколько дат проверять за один запуск
    val cursor: Int = 0,
    val best: Map<String, Int> = emptyMap(),  // дата → лучшая цена
    val lastInfo: String = "",
    val lastCheck: Long = 0
) {
    fun title() = "$originName ($origin) → $destName ($dest)"
    fun minPrice(): Int = best.values.minOrNull() ?: 0

    private fun list(s: String) = s.split(',').map { it.trim().lowercase() }.filter { it.isNotEmpty() }

    /** Проходит ли билет фильтры пользователя. */
    fun accepts(o: Offer): Boolean {
        if (directOnly && !Regex("(?i)без пересад|прям|non-?stop|direct").containsMatchIn(o.stops)) return false
        val h = o.dep.substringBefore(':').toIntOrNull()
        if (h != null && (depFrom > 0 || depTo < 24)) {
            if (h < depFrom || h >= depTo) return false
        }
        val al = o.airline.lowercase()
        val only = list(airlines)
        if (only.isNotEmpty() && only.none { al.contains(it) }) return false
        if (list(excludeAirlines).any { al.contains(it) }) return false
        return true
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("originName", originName).put("origin", origin)
        .put("destName", destName).put("dest", dest)
        .put("skyFrom", skyFrom).put("skyTo", skyTo)
        .put("dateFrom", dateFrom).put("dateTo", dateTo)
        .put("useAvia", useAvia).put("useSky", useSky)
        .put("notifyMode", notifyMode).put("maxPrice", maxPrice).put("minDrop", minDrop)
        .put("directOnly", directOnly).put("depFrom", depFrom).put("depTo", depTo)
        .put("airlines", airlines).put("excludeAirlines", excludeAirlines)
        .put("maxDates", maxDates).put("cursor", cursor).put("best", JSONObject(best))
        .put("lastInfo", lastInfo).put("lastCheck", lastCheck)

    companion object {
        fun fromJson(o: JSONObject): Watch {
            val b = o.optJSONObject("best") ?: JSONObject()
            return Watch(
                id = o.getLong("id"),
                originName = o.getString("originName"), origin = o.getString("origin"),
                destName = o.getString("destName"), dest = o.getString("dest"),
                skyFrom = o.optString("skyFrom"), skyTo = o.optString("skyTo"),
                dateFrom = o.getString("dateFrom"), dateTo = o.getString("dateTo"),
                useAvia = o.optBoolean("useAvia", true), useSky = o.optBoolean("useSky", true),
                notifyMode = o.optInt("notifyMode", NotifyMode.DROP),
                maxPrice = o.optInt("maxPrice"), minDrop = o.optInt("minDrop"),
                directOnly = o.optBoolean("directOnly"),
                depFrom = o.optInt("depFrom", 0), depTo = o.optInt("depTo", 24),
                airlines = o.optString("airlines"), excludeAirlines = o.optString("excludeAirlines"),
                maxDates = o.optInt("maxDates", 4), cursor = o.optInt("cursor"),
                best = b.keys().asSequence().associateWith { b.getInt(it) },
                lastInfo = o.optString("lastInfo"), lastCheck = o.optLong("lastCheck")
            )
        }
    }
}

class Storage(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("aviawatch", Context.MODE_PRIVATE)

    private fun int(k: String, d: Int) = prefs.getInt(k, d)
    private fun setInt(k: String, v: Int) = prefs.edit().putInt(k, v).apply()

    /** Интервал автопроверки в минутах. */
    var intervalMin: Int
        get() = int("intervalMin", 60)
        set(v) = setInt("intervalMin", v)

    /** Тихие часы: с quietFrom до quietTo уведомления не присылаются (0/0 = выключено). */
    var quietFrom: Int
        get() = int("quietFrom", 0)
        set(v) = setInt("quietFrom", v)
    var quietTo: Int
        get() = int("quietTo", 0)
        set(v) = setInt("quietTo", v)

    var wifiOnly: Boolean
        get() = prefs.getBoolean("wifiOnly", false)
        set(v) = prefs.edit().putBoolean("wifiOnly", v).apply()

    var autoOn: Boolean
        get() = prefs.getBoolean("autoOn", true)
        set(v) = prefs.edit().putBoolean("autoOn", v).apply()

    var aviaDomain: String
        get() = prefs.getString("aviaDomain", "aviasales.ru") ?: "aviasales.ru"
        set(v) = prefs.edit().putString("aviaDomain", v.trim().removePrefix("www.").ifEmpty { "aviasales.ru" }).apply()

    var skyDomain: String
        get() = prefs.getString("skyDomain", "skyscanner.ru") ?: "skyscanner.ru"
        set(v) = prefs.edit().putString("skyDomain", v.trim().removePrefix("www.").ifEmpty { "skyscanner.ru" }).apply()

    fun isQuietNow(): Boolean {
        val f = quietFrom; val t = quietTo
        if (f == t) return false
        val h = java.time.LocalTime.now().hour
        return if (f < t) h in f until t else (h >= f || h < t)   // напр. 23..7 через полночь
    }

    @Synchronized
    fun watches(): List<Watch> {
        val arr = JSONArray(prefs.getString("watches", "[]"))
        return (0 until arr.length()).mapNotNull { runCatching { Watch.fromJson(arr.getJSONObject(it)) }.getOrNull() }
    }

    @Synchronized
    fun saveAll(list: List<Watch>) {
        val arr = JSONArray()
        list.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("watches", arr.toString()).apply()
    }

    fun add(w: Watch) = saveAll(watches() + w)
    fun remove(id: Long) = saveAll(watches().filter { it.id != id })
    fun update(w: Watch) = saveAll(watches().map { if (it.id == w.id) w else it })
}
