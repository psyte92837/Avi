package com.example.aviawatch

import android.content.Context
import android.os.SystemClock
import android.webkit.WebView
import java.time.LocalDate
import kotlin.math.ceil

/** Поиск по направлению: открывает сайты по каждой дате, собирает билеты, шлёт уведомления. */
object Checker {

    /** Какие даты проверить в этот раз (с ротацией, чтобы за несколько запусков пройти весь период). */
    fun datesToCheck(w: Watch, all: Boolean): List<LocalDate> {
        val today = LocalDate.now()
        var d = maxOf(LocalDate.parse(w.dateFrom), today)
        val to = LocalDate.parse(w.dateTo)
        val dates = ArrayList<LocalDate>()
        while (!d.isAfter(to) && dates.size < 366) { dates += d; d = d.plusDays(1) }
        if (all || dates.size <= w.maxDates) return dates
        val step = ceil(dates.size / w.maxDates.toDouble()).toInt()
        val offset = w.cursor % step
        return dates.filterIndexed { i, _ -> i % step == offset }.take(w.maxDates)
    }

    class RunResult(val watch: Watch, val offers: List<Offer>, val log: String, val captcha: Boolean)

    suspend fun checkWatch(
        ctx: Context, w: Watch, notify: Boolean,
        view: WebView? = null, allDates: Boolean = false,
        deadline: Long = Long.MAX_VALUE,
        onProgress: (String) -> Unit = {}
    ): RunResult {
        val st = Storage(ctx)
        val offers = ArrayList<Offer>()
        val log = StringBuilder()
        var captcha = false
        val best = w.best.toMutableMap()
        val dates = datesToCheck(w, allDates)
        val quiet = st.isQuietNow()

        for (date in dates) {
            if (SystemClock.elapsedRealtime() > deadline) { log.append("Не успел все даты, продолжу в следующий раз\n"); break }
            val ds = date.toString()
            val jobs = buildList {
                if (w.useAvia) add(Sites.AVIASALES to Sites.aviasalesUrl(st.aviaDomain, w.origin, w.dest, date))
                if (w.useSky) add(Sites.SKYSCANNER to Sites.skyscannerUrl(st.skyDomain, w.skyFrom, w.skyTo, date))
            }
            for ((site, url) in jobs) {
                onProgress("$site · $ds…")
                val r = Scraper.scrape(ctx, site, ds, url, view)
                when {
                    r.captcha -> { captcha = true; log.append("$site $ds: сайт просит проверку «я не робот»\n") }
                    r.error != null && r.offers.isEmpty() -> log.append("$site $ds: ${r.error}\n")
                    else -> offers += r.offers.filter { w.accepts(it) }
                }
            }
            val dayBest = offers.filter { it.date == ds }.minByOrNull { it.price } ?: continue
            val prev = best[ds]
            val underLimit = w.maxPrice == 0 || dayBest.price <= w.maxPrice
            val drop = if (prev != null) prev - dayBest.price else 0
            val shouldNotify = when (w.notifyMode) {
                NotifyMode.DROP ->
                    underLimit && ((prev != null && drop > 0 && drop >= w.minDrop) ||
                            (prev == null && w.maxPrice > 0))      // впервые ниже порога
                NotifyMode.LIMIT -> w.maxPrice > 0 && underLimit
                else -> false                                       // ALWAYS — одно сводное ниже
            }
            if (notify && quiet.not() && shouldNotify) {
                val head = when {
                    prev != null && drop > 0 -> "Подешевело на $drop: $prev → ${dayBest.price}"
                    else -> "Цена ниже порога ${w.maxPrice}"
                }
                Notifier.show(ctx, (w.id + ds.hashCode()).toInt(), "✈ ${w.title()}",
                    "$head\n${dayBest.describe()}", dayBest.url)
            }
            best[ds] = dayBest.price
        }

        val top = offers.minByOrNull { it.price }
        if (notify && !quiet && w.notifyMode == NotifyMode.ALWAYS && top != null &&
            (w.maxPrice == 0 || top.price <= w.maxPrice)) {
            Notifier.show(ctx, w.id.toInt(), "✈ ${w.title()}", "Лучшая цена сейчас\n${top.describe()}", top.url)
        }
        val updated = w.copy(
            cursor = w.cursor + 1,
            best = best.filterKeys { runCatching { !LocalDate.parse(it).isBefore(LocalDate.now()) }.getOrDefault(false) },
            lastInfo = top?.describe() ?: w.lastInfo,
            lastCheck = System.currentTimeMillis()
        )
        st.update(updated)
        return RunResult(updated, offers.sortedBy { it.price }, log.toString(), captcha)
    }

    /** Фоновая проверка всех направлений с ограничением по времени. */
    suspend fun checkAll(ctx: Context, budgetMs: Long): String {
        val st = Storage(ctx)
        val deadline = SystemClock.elapsedRealtime() + budgetMs
        val log = StringBuilder()
        var captcha = false
        for (w in st.watches()) {
            if (LocalDate.parse(w.dateTo).isBefore(LocalDate.now())) continue
            val r = checkWatch(ctx, w, notify = true, deadline = deadline)
            captcha = captcha || r.captcha
            log.append(w.title()).append('\n').append(r.log)
        }
        if (captcha) {
            Notifier.show(ctx, 999, "Нужна проверка «я не робот»",
                "Откройте AviaWatch, включите «Показывать браузер» и нажмите «Найти» — пройдите проверку один раз.",
                "aviawatch://open")
        }
        return log.toString()
    }
}
