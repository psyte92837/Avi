package com.example.aviawatch

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.android.material.card.MaterialCardView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var st: Storage
    private lateinit var status: TextView
    private lateinit var watchList: LinearLayout
    private lateinit var results: LinearLayout
    private lateinit var webHolder: FrameLayout
    private lateinit var showBrowser: CompoundButton
    private var webView: WebView? = null
    private var searchJob: Job? = null
    private var dateFrom: LocalDate = LocalDate.now().plusDays(7)
    private var dateTo: LocalDate = LocalDate.now().plusDays(14)

    private fun <T : View> v(id: Int): T = findViewById(id)
    private fun EditText.str() = text.toString().trim()
    private fun EditText.int(def: Int) = str().toIntOrNull() ?: def

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        st = Storage(this)
        Notifier.createChannel(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val origin = v<EditText>(R.id.origin)
        val dest = v<EditText>(R.id.dest)
        val btnFrom = v<Button>(R.id.dateFrom)
        val btnTo = v<Button>(R.id.dateTo)
        val useAvia = v<CheckBox>(R.id.useAvia)
        val useSky = v<CheckBox>(R.id.useSky)
        val notifyMode = v<RadioGroup>(R.id.notifyMode)
        val maxPrice = v<EditText>(R.id.maxPrice)
        val minDrop = v<EditText>(R.id.minDrop)
        val directOnly = v<CheckBox>(R.id.directOnly)
        val depFrom = v<EditText>(R.id.depFrom)
        val depTo = v<EditText>(R.id.depTo)
        val airlines = v<EditText>(R.id.airlines)
        val exclude = v<EditText>(R.id.excludeAirlines)
        val maxDates = v<EditText>(R.id.maxDates)
        val skyFrom = v<EditText>(R.id.skyFrom)
        val skyTo = v<EditText>(R.id.skyTo)
        val interval = v<EditText>(R.id.interval)
        val quietFrom = v<EditText>(R.id.quietFrom)
        val quietTo = v<EditText>(R.id.quietTo)
        val wifiOnly = v<CompoundButton>(R.id.wifiOnly)
        val autoOn = v<CompoundButton>(R.id.autoOn)
        val aviaDomain = v<EditText>(R.id.aviaDomain)
        val skyDomain = v<EditText>(R.id.skyDomain)
        showBrowser = v(R.id.showBrowser)
        webHolder = v(R.id.webHolder)
        status = v(R.id.status)
        watchList = v(R.id.watchList)
        results = v(R.id.results)

        // текущие настройки
        interval.setText(st.intervalMin.toString())
        quietFrom.setText(st.quietFrom.toString())
        quietTo.setText(st.quietTo.toString())
        wifiOnly.isChecked = st.wifiOnly
        autoOn.isChecked = st.autoOn
        aviaDomain.setText(st.aviaDomain)
        skyDomain.setText(st.skyDomain)

        btnFrom.text = "С $dateFrom"; btnTo.text = "По $dateTo"
        btnFrom.setOnClickListener {
            pickDate(dateFrom) {
                dateFrom = it; btnFrom.text = "С $it"
                if (dateTo.isBefore(it)) { dateTo = it; btnTo.text = "По $it" }
            }
        }
        btnTo.setOnClickListener {
            pickDate(dateTo) { if (!it.isBefore(dateFrom)) { dateTo = it; btnTo.text = "По $it" } }
        }

        showBrowser.setOnCheckedChangeListener { _, on -> setBrowserVisible(on) }

        fun saveSettings() {
            st.intervalMin = interval.int(60).coerceIn(1, 24 * 60)
            st.quietFrom = quietFrom.int(0).coerceIn(0, 23)
            st.quietTo = quietTo.int(0).coerceIn(0, 23)
            st.wifiOnly = wifiOnly.isChecked
            st.autoOn = autoOn.isChecked
            st.aviaDomain = aviaDomain.str()
            st.skyDomain = skyDomain.str()
        }

        v<Button>(R.id.btnSchedule).setOnClickListener {
            saveSettings()
            PriceWorker.schedule(this)
            status.text = if (st.autoOn)
                "Автопроверка каждые ${st.intervalMin} мин." +
                        (if (st.intervalMin < 15) "\nВнимание: при выключенном экране Android может проверять реже." else "")
            else "Автопроверка выключена"
        }

        v<Button>(R.id.btnAdd).setOnClickListener {
            val o = origin.str(); val d = dest.str()
            if (o.isEmpty() || d.isEmpty()) { status.text = "Укажите города"; return@setOnClickListener }
            if (!useAvia.isChecked && !useSky.isChecked) { status.text = "Выберите хотя бы один сайт"; return@setOnClickListener }
            saveSettings()
            status.text = "Определяю города…"
            lifecycleScope.launch {
                try {
                    val (oc, dc) = withContext(Dispatchers.IO) { Sites.resolveCity(o) to Sites.resolveCity(d) }
                    val mode = when (notifyMode.checkedRadioButtonId) {
                        R.id.modeLimit -> NotifyMode.LIMIT
                        R.id.modeAlways -> NotifyMode.ALWAYS
                        else -> NotifyMode.DROP
                    }
                    val w = Watch(
                        id = System.currentTimeMillis(),
                        originName = o, origin = oc, destName = d, dest = dc,
                        skyFrom = skyFrom.str().ifEmpty { Sites.skyscannerCode(oc) },
                        skyTo = skyTo.str().ifEmpty { Sites.skyscannerCode(dc) },
                        dateFrom = dateFrom.toString(), dateTo = dateTo.toString(),
                        useAvia = useAvia.isChecked, useSky = useSky.isChecked,
                        notifyMode = mode,
                        maxPrice = maxPrice.int(0), minDrop = minDrop.int(0),
                        directOnly = directOnly.isChecked,
                        depFrom = depFrom.int(0).coerceIn(0, 23), depTo = depTo.int(24).coerceIn(1, 24),
                        airlines = airlines.str(), excludeAirlines = exclude.str(),
                        maxDates = maxDates.int(4).coerceIn(1, 60)
                    )
                    st.add(w)
                    PriceWorker.schedule(this@MainActivity)
                    renderWatches()
                    runSearch(w)
                } catch (e: Exception) {
                    status.text = "Ошибка: ${e.message}"
                }
            }
        }

        renderWatches()
        PriceWorker.schedule(this)
    }

    private fun setBrowserVisible(on: Boolean) {
        if (on && webView == null) {
            webView = WebView(this).also {
                Scraper.setup(it)
                webHolder.addView(it, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT))
            }
        }
        webHolder.visibility = if (on) View.VISIBLE else View.GONE
    }

    private fun pickDate(initial: LocalDate, onPick: (LocalDate) -> Unit) {
        DatePickerDialog(this, { _, y, m, d -> onPick(LocalDate.of(y, m + 1, d)) },
            initial.year, initial.monthValue - 1, initial.dayOfMonth).apply {
            datePicker.minDate = System.currentTimeMillis() - 1000
        }.show()
    }

    /** Ручной поиск по направлению: все даты периода, результаты на экране. */
    private fun runSearch(w: Watch) {
        searchJob?.cancel()
        results.removeAllViews()
        val view = if (showBrowser.isChecked) webView else null
        val dates = Checker.datesToCheck(w, all = true)
        status.text = "Ищу ${w.title()} — ${dates.size} дат(ы), это займёт ~${dates.size * (if (w.useAvia && w.useSky) 2 else 1) * 40 / 60 + 1} мин…"
        searchJob = lifecycleScope.launch {
            val r = Checker.checkWatch(this@MainActivity, w, notify = false, view = view, allDates = true) {
                status.text = "Ищу ${w.title()}\n$it"
            }
            renderWatches()
            status.text = buildString {
                append("${w.title()}: найдено ${r.offers.size}")
                r.offers.firstOrNull()?.let { append(", лучшая цена ${it.price} ${it.currency}") }
                if (r.captcha) append("\n⚠ Сайт попросил проверку «я не робот». Включите «Показывать браузер», пройдите её и нажмите на направление ещё раз.")
                if (r.log.isNotBlank()) append("\n").append(r.log.trim())
            }
            r.offers.take(60).forEach { o ->
                results.addView(card(o.describe()) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(o.url)))
                })
            }
        }
    }

    private fun renderWatches() {
        watchList.removeAllViews()
        val list = st.watches()
        if (list.isEmpty()) { watchList.addView(label("Пока пусто")); return }
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        val modes = arrayOf("если подешевело", "ниже порога", "каждая проверка")
        list.forEach { w ->
            val sites = listOfNotNull(Sites.AVIASALES.takeIf { w.useAvia }, Sites.SKYSCANNER.takeIf { w.useSky })
            val opts = buildList {
                add("уведомлять: ${modes.getOrElse(w.notifyMode) { "" }}")
                if (w.maxPrice > 0) add("порог ${w.maxPrice}")
                if (w.minDrop > 0) add("снижение от ${w.minDrop}")
                if (w.directOnly) add("прямые")
                if (w.depFrom > 0 || w.depTo < 24) add("вылет ${w.depFrom}–${w.depTo} ч")
                if (w.airlines.isNotBlank()) add("только: ${w.airlines}")
                if (w.excludeAirlines.isNotBlank()) add("без: ${w.excludeAirlines}")
            }.joinToString(" · ")
            val minP = if (w.minPrice() > 0) "\nМинимум за период: ${w.minPrice()}" else ""
            val checked = if (w.lastCheck > 0) "\nпроверено ${fmt.format(Date(w.lastCheck))}" else ""
            val body = "${w.title()}\n${w.dateFrom} — ${w.dateTo} · ${sites.joinToString(", ")}\n$opts" +
                    minP + (if (w.lastInfo.isNotEmpty()) "\n\n${w.lastInfo}" else "") + checked
            val c = card(body) { runSearch(w) }
            c.setOnLongClickListener {
                st.remove(w.id); renderWatches()
                status.text = "Удалено: ${w.title()}"
                PriceWorker.schedule(this)
                true
            }
            watchList.addView(c)
        }
        watchList.addView(label("Нажмите — искать сейчас, удерживайте — удалить").apply { alpha = 0.6f })
    }

    private fun label(s: String): TextView = TextView(this).apply { text = s; setPadding(0, 8, 0, 8) }

    private fun card(s: String, onClick: () -> Unit): View {
        val dp = resources.displayMetrics.density
        return MaterialCardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (8 * dp).toInt() }
            radius = 12 * dp
            isClickable = true
            setOnClickListener { onClick() }
            addView(TextView(context).apply {
                text = s
                val p = (12 * dp).toInt()
                setPadding(p, p, p, p)
            })
        }
    }

    override fun onDestroy() {
        webView?.destroy()
        super.onDestroy()
    }
}
