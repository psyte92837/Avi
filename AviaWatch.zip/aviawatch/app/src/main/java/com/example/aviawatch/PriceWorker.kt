package com.example.aviawatch

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

/**
 * Фоновая проверка. Работает цепочкой: после каждой проверки ставит
 * следующую через N минут — так можно задать любой интервал, даже 1 минуту
 * (обычные периодические задачи Android не чаще раза в 15 минут).
 */
class PriceWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val st = Storage(applicationContext)
        if (!st.autoOn || st.watches().isEmpty()) return Result.success()
        try {
            // Android даёт фоновой задаче ~10 минут, оставляем запас
            Checker.checkAll(applicationContext, budgetMs = 8 * 60 * 1000L)
        } finally {
            enqueue(applicationContext, st.intervalMin, ExistingWorkPolicy.APPEND_OR_REPLACE)
        }
        return Result.success()
    }

    companion object {
        private const val NAME = "price_check"

        private fun enqueue(ctx: Context, minutes: Int, policy: ExistingWorkPolicy, delay: Boolean = true) {
            val st = Storage(ctx)
            val req = OneTimeWorkRequestBuilder<PriceWorker>()
                .apply { if (delay) setInitialDelay(minutes.coerceAtLeast(1).toLong(), TimeUnit.MINUTES) }
                .setConstraints(
                    Constraints.Builder()
                        .setRequiredNetworkType(if (st.wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED)
                        .build()
                )
                .build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(NAME, policy, req)
        }

        /** Запустить/перезапустить автопроверку с текущими настройками. */
        fun schedule(ctx: Context) {
            val st = Storage(ctx)
            if (!st.autoOn || st.watches().isEmpty()) { cancel(ctx); return }
            enqueue(ctx, st.intervalMin, ExistingWorkPolicy.REPLACE)
        }

        fun cancel(ctx: Context) = WorkManager.getInstance(ctx).cancelUniqueWork(NAME)
    }
}
