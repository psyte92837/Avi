package com.example.aviawatch

import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate
import java.time.format.DateTimeFormatter

/** Один билет, считанный со страницы сайта. */
data class Offer(
    val site: String,        // "Aviasales" / "Skyscanner"
    val date: String,        // yyyy-MM-dd
    val price: Int,
    val currency: String,
    val airline: String,
    val dep: String,         // время вылета HH:mm
    val arr: String,         // время прилёта HH:mm
    val stops: String,
    val url: String
) {
    fun describe(): String {
        val time = if (dep.isNotEmpty()) " · $dep–$arr" else ""
        val st = if (stops.isNotEmpty()) " · $stops" else ""
        return "$price $currency · ${airline.ifEmpty { "авиакомпания ?" }}\n$date$time$st · $site"
    }
}

/** Как строить адреса поиска на сайтах. */
object Sites {
    const val AVIASALES = "Aviasales"
    const val SKYSCANNER = "Skyscanner"

    // aviasales.ru/search/FRU1211MOW1  →  откуда + ДДММ + куда + взрослых
    fun aviasalesUrl(domain: String, from: String, to: String, date: LocalDate): String =
        "https://www.$domain/search/${from.uppercase()}${date.format(DateTimeFormatter.ofPattern("ddMM"))}${to.uppercase()}1"

    // skyscanner.ru/transport/flights/fru/mosc/261112/  →  ГГММДД
    fun skyscannerUrl(domain: String, from: String, to: String, date: LocalDate): String =
        "https://www.$domain/transport/flights/${from.lowercase()}/${to.lowercase()}/" +
                "${date.format(DateTimeFormatter.ofPattern("yyMMdd"))}/?adultsv2=1&cabinclass=economy&rtn=0"

    /** У Skyscanner для городов с несколькими аэропортами свои коды. */
    fun skyscannerCode(iata: String): String = when (iata.uppercase()) {
        "MOW" -> "mosc"; "LON" -> "lond"; "PAR" -> "pari"; "IST" -> "ista"
        "NYC" -> "nyca"; "MIL" -> "mila"; "ROM" -> "rome"; "BER" -> "berl"
        "TYO" -> "tyoa"; "SEL" -> "sela"; "BJS" -> "bjsa"; "WAS" -> "wasa"
        else -> iata.lowercase()
    }

    /** «Бишкек» → FRU (бесплатный автокомплит, без токена). */
    fun resolveCity(input: String): String {
        val t = input.trim()
        if (t.length == 3 && t.all { it in 'A'..'Z' || it in 'a'..'z' }) return t.uppercase()
        val url = "https://autocomplete.travelpayouts.com/places2?term=" +
                URLEncoder.encode(t, "UTF-8") + "&locale=ru&types[]=city&types[]=airport"
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000; conn.readTimeout = 15000
        val body = try { conn.inputStream.bufferedReader().use { it.readText() } } finally { conn.disconnect() }
        val arr = JSONArray(body)
        if (arr.length() == 0) throw RuntimeException("Город «$t» не найден")
        val first = arr.getJSONObject(0)
        return first.optString("city_code").ifEmpty { first.getString("code") }
    }
}
